export const cloud = {
    id: null
};