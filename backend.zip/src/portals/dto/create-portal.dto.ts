export class CreatePortalDto {}
